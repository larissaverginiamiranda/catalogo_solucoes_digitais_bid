const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import { Brain, Link as LinkIcon, Globe, Cog, BarChart3, ArrowRight, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const ICON_MAP = { Brain, Link: LinkIcon, Globe, Cog, BarChart3 };

export default function Technologies() {
  const [technologies, setTechnologies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Technology.list("name", 20).then((data) => {
      setTechnologies(data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="max-w-5xl mx-auto px-6 lg:px-8 pt-12 pb-10">
        <div className="mb-4">
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/10 text-secondary text-xs font-semibold uppercase tracking-widest">
            Catálogo de Soluções
          </span>
          <span className="text-xs text-muted-foreground ml-2">Arcabouço Tecnológico • Modernização Fiscal</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-primary tracking-tight leading-tight mb-5">
          Tecnologias Utilizadas
        </h1>
        <p className="text-muted-foreground text-base leading-relaxed max-w-xl">
          Explore o arcabouço tecnológico que sustenta a modernização fiscal. De inteligência artificial generativa a redes descentralizadas, cada solução é categorizada por sua maturidade e aplicabilidade institucional.
        </p>
      </section>

      {/* Cards Grid */}
      <section className="max-w-5xl mx-auto px-6 lg:px-8 pb-16">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-muted border-t-secondary rounded-full animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {technologies.map((tech) => {
              const IconComp = ICON_MAP[tech.icon] || BarChart3;
              return (
                <Link key={tech.id} to={`/tecnologia/${tech.slug}`} className="group">
                  <article className="bg-card border border-border rounded-2xl p-8 hover:shadow-md hover:border-secondary/30 transition-all duration-300 h-full flex flex-col">
                    <div className="w-10 h-10 rounded-lg bg-primary/5 flex items-center justify-center mb-5">
                      <IconComp className="w-5 h-5 text-primary" />
                    </div>
                    <h2 className="text-lg font-bold text-primary mb-3 leading-snug">{tech.name}</h2>
                    <p className="text-sm text-muted-foreground leading-relaxed flex-1">{tech.description}</p>
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-secondary mt-6 group-hover:gap-3 transition-all">
                      Acessar <ArrowRight className="w-4 h-4" />
                    </div>
                  </article>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* CTA Banner */}
      <section className="max-w-5xl mx-auto px-6 lg:px-8 pb-16">
        <div className="bg-card border border-border rounded-2xl p-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h3 className="text-xl font-bold text-primary mb-2">Transformação Digital Fazendária</h3>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-md">
              Acesse a documentação técnica completa de cada dimensão e os roteiros de implementação recomendados pelo BID para elevar a maturidade institucional.
            </p>
          </div>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold gap-2 shrink-0 px-6">
            <Download className="w-4 h-4" />
            Baixar Metodologia
          </Button>
        </div>
      </section>
    </div>
  );
}