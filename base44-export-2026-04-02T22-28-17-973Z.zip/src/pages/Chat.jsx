const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useRef, useEffect } from "react";

import { Link } from "react-router-dom";
import { Send, Bot, User, Loader2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import ReactMarkdown from "react-markdown";

const SYSTEM_CONTEXT = `Você é o assistente do Catálogo de Soluções para uma Administração Tributária Digital do BID.
Você ajuda gestores públicos e técnicos a encontrar soluções digitais fiscais.
As dimensões são: AT1 (Políticas e Gasto Tributário), AT2 (Cadastro e Obrigação Tributária), AT3 (Fiscalização e Inteligência Fiscal), AT4 (Contencioso Fiscal), AT5 (Serviços ao Contribuinte).
As tecnologias são: LLMs, Blockchain, APIs RESTful, Automação/RPA, Data Analytics.
Responda de forma clara, objetiva e em português. Sugira soluções e dimensões relevantes.`;

export default function Chat() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Olá! Sou o assistente do Catálogo de Soluções Tributárias do BID. Como posso ajudá-lo? Você pode me perguntar sobre dimensões, tecnologias ou soluções específicas." },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setIsLoading(true);

    const response = await db.integrations.Core.InvokeLLM({
      prompt: `${SYSTEM_CONTEXT}\n\nHistórico:\n${messages.map((m) => `${m.role}: ${m.content}`).join("\n")}\n\nUsuário: ${userMsg}\n\nResponda:`,
      add_context_from_internet: false,
    });

    setMessages((prev) => [...prev, { role: "assistant", content: response }]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]">
      {/* Header */}
      <div className="border-b border-border bg-card px-4 sm:px-6 py-4 flex items-center gap-4">
        <Link to="/">
          <Button variant="ghost" size="icon" className="shrink-0">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="font-bold text-foreground flex items-center gap-2">
            <Bot className="w-5 h-5 text-secondary" />
            Assistente do Catálogo
          </h1>
          <p className="text-xs text-muted-foreground">Navegação por linguagem natural (RAG)</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-lg bg-secondary/10 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-secondary" />
              </div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              msg.role === "user"
                ? "bg-primary text-primary-foreground"
                : "bg-card border border-border"
            }`}>
              {msg.role === "user" ? (
                <p className="text-sm leading-relaxed">{msg.content}</p>
              ) : (
                <ReactMarkdown className="text-sm prose prose-sm prose-slate max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                  {msg.content}
                </ReactMarkdown>
              )}
            </div>
            {msg.role === "user" && (
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4 text-primary-foreground" />
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-lg bg-secondary/10 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-secondary" />
            </div>
            <div className="bg-card border border-border rounded-2xl px-4 py-3">
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card px-4 sm:px-6 py-4">
        <div className="max-w-3xl mx-auto flex gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Pergunte sobre soluções, dimensões ou tecnologias..."
            className="flex-1 rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-secondary/50 focus:border-secondary transition-all"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="bg-secondary text-primary hover:bg-secondary/90 rounded-xl px-5"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}