import Breadcrumbs from "../components/catalog/Breadcrumbs";

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Breadcrumbs items={[{ label: "Sobre o Catálogo" }]} />

      <div className="mb-10">
        <p className="text-secondary text-sm font-semibold tracking-widest uppercase mb-3">// Sobre</p>
        <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
          Sobre o Catálogo
        </h1>
      </div>

      <div className="prose prose-lg max-w-none text-muted-foreground">
        <p className="leading-relaxed">
          A modernização da administração tributária não se limita à incorporação de novas tecnologias. Trata-se de uma resposta necessária a desafios estruturais que, há décadas, comprometem a relação entre o Fisco e o contribuinte.
        </p>

        <h2 className="text-xl font-bold text-foreground mt-10 mb-4">Custo da Conformidade</h2>
        <p className="leading-relaxed">
          Em sistemas tributários complexos e fragmentados, o contribuinte despende recursos excessivos em tempo e capital apenas para cumprir as obrigações. A simplificação da jornada declaratória e a automação do cumprimento das obrigações fiscais não apenas reduzem custos, mas ampliam a base de arrecadação de forma sustentável.
        </p>

        <h2 className="text-xl font-bold text-foreground mt-10 mb-4">Efetividade da Fiscalização</h2>
        <p className="leading-relaxed">
          O hiato entre o fato gerador e a ação fiscal é longo demais para garantir tanto a recuperação efetiva do crédito quanto o efeito dissuasório necessário. A incorporação de inteligência analítica, monitoramento contínuo e atuação mais tempestiva permite aumentar a eficiência da fiscalização.
        </p>

        <h2 className="text-xl font-bold text-foreground mt-10 mb-4">Relacionamento Fisco-Contribuinte</h2>
        <p className="leading-relaxed">
          A construção de um modelo baseado em transparência, orientação e comunicação personalizada permite reduzir conflitos, aumentar a conformidade espontânea e reposicionar o Fisco como agente indutor do desenvolvimento econômico.
        </p>

        <div className="mt-12 p-8 bg-primary/5 rounded-xl border border-primary/10">
          <p className="text-foreground font-semibold mb-3">Banco Interamericano de Desenvolvimento (BID)</p>
          <p className="leading-relaxed text-sm">
            Por meio de sua Divisão Fiscal, apresenta o Catálogo de Soluções para uma Administração Tributária Digital. O catálogo tem como objetivo central compartilhar soluções digitais já testadas e implementadas com sucesso em diferentes contextos, funcionando como um repositório vivo de práticas inovadoras.
          </p>
        </div>

        <h2 className="text-xl font-bold text-foreground mt-10 mb-4">Como Navegar</h2>
        <div className="space-y-4">
          <div className="flex gap-4 items-start">
            <span className="w-8 h-8 rounded-full bg-secondary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">1</span>
            <div>
              <p className="font-semibold text-foreground">Navegue pelas Dimensões</p>
              <p className="text-sm">Representam os grandes eixos da administração tributária. São a porta de entrada para a navegação.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <span className="w-8 h-8 rounded-full bg-secondary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">2</span>
            <div>
              <p className="font-semibold text-foreground">Navegue pelas Soluções</p>
              <p className="text-sm">Dentro de cada dimensão, o catálogo lista soluções específicas que respondem a desafios ou necessidades identificadas.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <span className="w-8 h-8 rounded-full bg-secondary text-primary-foreground flex items-center justify-center font-bold text-sm shrink-0">3</span>
            <div>
              <p className="font-semibold text-foreground">Detalhamento das Soluções</p>
              <p className="text-sm">Cada solução apresenta descrição, funcionalidades, resultados evidenciados, casos de referência e tecnologias associadas.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}