const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

import { CheckCircle, Building2, Lightbulb } from "lucide-react";
import Breadcrumbs from "../components/catalog/Breadcrumbs";
import TechBadge from "../components/catalog/TechBadge";

export default function SolutionDetail() {
  const { id } = useParams();
  const [solution, setSolution] = useState(null);
  const [dimension, setDimension] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Solution.filter({ id }, null, 1).then(async (sols) => {
      const sol = sols[0];
      setSolution(sol || null);
      if (sol?.dimension_id) {
        const dims = await db.entities.Dimension.filter({ id: sol.dimension_id }, null, 1);
        setDimension(dims[0] || null);
      }
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center py-32">
        <div className="w-8 h-8 border-4 border-muted border-t-secondary rounded-full animate-spin" />
      </div>
    );
  }

  if (!solution) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Solução não encontrada</h1>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <Breadcrumbs items={[
            { label: "Dimensões", href: "/dimensoes" },
            ...(dimension ? [{ label: dimension.title, href: `/dimensao/${dimension.id}` }] : []),
            { label: solution.title },
          ]} />

          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
            <div>
              <p className="text-secondary text-sm font-semibold tracking-widest uppercase mb-2">
                // {solution.code}
              </p>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
                {solution.title}
              </h1>
            </div>
            {solution.technology_names?.length > 0 && (
              <div className="flex flex-wrap gap-2 shrink-0">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mr-2 self-center">Tecnologias</span>
                {solution.technology_names.map((t) => (
                  <TechBadge key={t} name={t} />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16">
          {/* Description */}
          <div>
            <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-secondary" />
              Descrição
            </h2>
            <p className="text-muted-foreground leading-relaxed">{solution.description}</p>
          </div>

          {/* Results */}
          {solution.results?.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-success" />
                Resultados Evidenciados
              </h2>
              <ul className="space-y-3">
                {solution.results.map((r, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                    <p className="text-muted-foreground leading-relaxed">{r}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Functionalities */}
          {solution.functionalities?.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-4">Funcionalidades</h2>
              <ul className="space-y-3">
                {solution.functionalities.map((f, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                    <p className="text-muted-foreground leading-relaxed">{f}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Use Cases */}
          {solution.use_cases?.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-primary" />
                Casos de Referência
              </h2>
              <ul className="space-y-3">
                {solution.use_cases.map((u, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                    <p className="text-muted-foreground leading-relaxed">{u}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}