const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";

import { Brain, Link as LinkIcon, Globe, Cog, BarChart3, Search, Filter, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Breadcrumbs from "../components/catalog/Breadcrumbs";
import TechBadge from "../components/catalog/TechBadge";

const ICON_MAP = { Brain, Link: LinkIcon, Globe, Cog, BarChart3 };

const TECH_STATS = {
  "llms": [
    { label: "Impacto em Atendimento", value: "+60% Eficiência" },
    { label: "Velocidade de Resposta", value: "Tempo Real" },
  ],
  "blockchain": [
    { label: "Segurança de Dados", value: "Alta Integridade" },
    { label: "Redução de Fraudes", value: "-40% Inconsistências" },
  ],
  "apis-restful": [
    { label: "Integração de Sistemas", value: "Universal" },
    { label: "Velocidade de Troca", value: "Milissegundos" },
  ],
  "automacao-rpa": [
    { label: "Impacto em Fiscalização", value: "+45% Eficiência" },
    { label: "Redução de Tarefas Manuais", value: "-70% Operacional" },
  ],
  "data-analytics": [
    { label: "Volume Processado", value: "Big Data" },
    { label: "Precisão de Insights", value: "+85% Acurácia" },
  ],
};

const DIMENSION_LABELS = {
  "69ce6750a944cf105184153a": "Políticas e Gasto",
  "69ce6750a944cf105184153b": "Cadastro",
  "69ce6750a944cf105184153c": "Fiscalização",
  "69ce6750a944cf105184153d": "Contencioso",
  "69ce6750a944cf105184153e": "Serviços",
};

const DIMENSION_COLORS = {
  "69ce6750a944cf105184153a": "bg-blue-100 text-blue-700",
  "69ce6750a944cf105184153b": "bg-purple-100 text-purple-700",
  "69ce6750a944cf105184153c": "bg-orange-100 text-orange-700",
  "69ce6750a944cf105184153d": "bg-red-100 text-red-700",
  "69ce6750a944cf105184153e": "bg-green-100 text-green-700",
};

const PAGE_SIZE = 6;

export default function TechnologyDetail() {
  const { slug } = useParams();
  const [technology, setTechnology] = useState(null);
  const [allSolutions, setAllSolutions] = useState([]);
  const [dimensions, setDimensions] = useState([]);
  const [search, setSearch] = useState("");
  const [filterDim, setFilterDim] = useState("all");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      db.entities.Technology.filter({ slug }, null, 1),
      db.entities.Solution.list("order", 200),
      db.entities.Dimension.list("order", 10),
    ]).then(([techs, sols, dims]) => {
      const tech = techs[0] || null;
      setTechnology(tech);
      setDimensions(dims);
      if (tech) {
        const filtered = sols.filter(
          (s) =>
            s.technology_names?.some((t) =>
              t.toLowerCase().includes(tech.name.split(" ")[0].toLowerCase()) ||
              tech.name.toLowerCase().includes(t.split(" ")[0].toLowerCase())
            )
        );
        setAllSolutions(filtered);
      } else {
        setAllSolutions(sols);
      }
      setLoading(false);
    });
  }, [slug]);

  const filtered = allSolutions.filter((s) => {
    const matchSearch =
      !search ||
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.description?.toLowerCase().includes(search.toLowerCase());
    const matchDim = filterDim === "all" || s.dimension_id === filterDim;
    return matchSearch && matchDim;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const stats = TECH_STATS[slug] || [
    { label: "Soluções Disponíveis", value: `${allSolutions.length} Soluções` },
    { label: "Casos de Uso", value: "Múltiplos" },
  ];

  if (loading) {
    return (
      <div className="flex justify-center py-32">
        <div className="w-8 h-8 border-4 border-muted border-t-secondary rounded-full animate-spin" />
      </div>
    );
  }

  if (!technology) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Tecnologia não encontrada</h1>
        <Link to="/tecnologias" className="text-secondary mt-4 inline-block">← Voltar para Tecnologias</Link>
      </div>
    );
  }

  const IconComp = ICON_MAP[technology.icon] || BarChart3;

  return (
    <div>
      {/* Hero */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
          <Breadcrumbs items={[
            { label: "Tecnologias", href: "/tecnologias" },
            { label: technology.name },
          ]} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-start">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-xl bg-secondary/20 flex items-center justify-center shrink-0">
                  <IconComp className="w-7 h-7 text-secondary" />
                </div>
              </div>
              <h1 className="text-3xl md:text-5xl font-bold tracking-tight leading-tight mb-5">
                {technology.name}
              </h1>
              <p className="text-primary-foreground/70 leading-relaxed text-lg max-w-2xl">
                {technology.description}
              </p>
            </div>

            {/* Stats cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
              {stats.map((stat, i) => (
                <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-5 backdrop-blur-sm">
                  <p className="text-xs font-semibold tracking-widest uppercase text-secondary mb-2">{stat.label}</p>
                  <p className="text-xl font-bold text-primary-foreground">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solutions section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-1 h-6 bg-secondary rounded-full" />
            <h2 className="text-2xl font-bold text-foreground">Detalhamento das Soluções</h2>
          </div>
          <p className="text-sm text-muted-foreground ml-4">
            Exibindo {paginated.length} de {filtered.length} soluções baseadas em {technology.name}.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-card border border-border rounded-xl p-4 mb-8">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                placeholder={`Pesquisar em ${technology.name}...`}
                className="w-full pl-10 pr-4 py-2.5 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-secondary/40 focus:border-secondary transition-all"
              />
            </div>
            <select
              value={filterDim}
              onChange={(e) => { setFilterDim(e.target.value); setPage(1); }}
              className="px-4 py-2.5 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-secondary/40 focus:border-secondary transition-all"
            >
              <option value="all">Todas as Dimensões</option>
              {dimensions.map((d) => (
                <option key={d.id} value={d.id}>{d.title}</option>
              ))}
            </select>
            <Button variant="outline" size="sm" className="gap-2 self-stretch px-4">
              <Filter className="w-4 h-4" />
              Filtrar
            </Button>
          </div>

          {/* Quick filter badges */}
          <div className="flex flex-wrap gap-2 mt-3">
            {dimensions.map((d) => (
              <button
                key={d.id}
                onClick={() => { setFilterDim(filterDim === d.id ? "all" : d.id); setPage(1); }}
                className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                  filterDim === d.id
                    ? "bg-secondary text-primary border-secondary"
                    : "border-border text-muted-foreground hover:border-secondary/40 hover:text-foreground"
                }`}
              >
                {d.code}
              </button>
            ))}
          </div>
        </div>

        {/* Solutions Grid */}
        {paginated.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground border border-dashed border-border rounded-xl">
            <Search className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhuma solução encontrada</p>
            <p className="text-sm mt-1">Tente ajustar os filtros ou a busca</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {paginated.map((sol) => {
              const dimLabel = DIMENSION_LABELS[sol.dimension_id];
              const dimColor = DIMENSION_COLORS[sol.dimension_id] || "bg-gray-100 text-gray-700";
              return (
                <article key={sol.id} className="bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:border-secondary/30 transition-all duration-300 group flex flex-col">
                  {dimLabel && (
                    <span className={`inline-flex self-start px-2.5 py-1 rounded-md text-[11px] font-semibold uppercase tracking-wide mb-4 ${dimColor}`}>
                      {dimLabel}
                    </span>
                  )}
                  <h3 className="font-bold text-foreground text-base leading-snug mb-3 group-hover:text-secondary transition-colors">
                    {sol.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">
                    {sol.description}
                  </p>
                  {sol.technology_names?.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-4">
                      {sol.technology_names.slice(0, 2).map((t) => (
                        <TechBadge key={t} name={t} />
                      ))}
                    </div>
                  )}
                  <Link
                    to={`/solucao/${sol.id}`}
                    className="inline-flex items-center gap-1.5 text-sm font-semibold text-secondary mt-5 hover:gap-3 transition-all"
                  >
                    Ver detalhes
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </article>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-12">
            <Button
              variant="outline"
              size="icon"
              disabled={page === 1}
              onClick={() => setPage((p) => p - 1)}
              className="w-9 h-9"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>

            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
              if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
                return (
                  <Button
                    key={p}
                    variant={p === page ? "default" : "outline"}
                    size="icon"
                    className={`w-9 h-9 ${p === page ? "bg-secondary text-primary hover:bg-secondary/90" : ""}`}
                    onClick={() => setPage(p)}
                  >
                    {p}
                  </Button>
                );
              }
              if (Math.abs(p - page) === 2) {
                return <span key={p} className="text-muted-foreground">...</span>;
              }
              return null;
            })}

            <Button
              variant="outline"
              size="icon"
              disabled={page === totalPages}
              onClick={() => setPage((p) => p + 1)}
              className="w-9 h-9"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </section>
    </div>
  );
}