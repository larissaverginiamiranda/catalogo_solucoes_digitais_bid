const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";

import { Target, ClipboardList, Search, Scale, Users, Filter, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Breadcrumbs from "../components/catalog/Breadcrumbs";
import TechBadge from "../components/catalog/TechBadge";

const ICON_MAP = { Target, ClipboardList, Search, Scale, Users };

const DIMENSION_STATS = {
  "AT 1": [
    { label: "Impacto em Planejamento", value: "Alta Precisão" },
    { label: "Cobertura", value: "Estratégica" },
  ],
  "AT 2": [
    { label: "Redução de Duplicidades", value: "-40% Inconsistências" },
    { label: "Atualização Cadastral", value: "Automática" },
  ],
  "AT 3": [
    { label: "Impacto em Fiscalização", value: "+45% Eficiência" },
    { label: "Velocidade de Resposta", value: "Tempo Real" },
  ],
  "AT 4": [
    { label: "Recuperação de Crédito", value: "+30% Efetividade" },
    { label: "Redução de Litígios", value: "Significativa" },
  ],
  "AT 5": [
    { label: "Satisfação do Contribuinte", value: "+60% Aprovação" },
    { label: "Atendimento", value: "Multicanal" },
  ],
};

const PAGE_SIZE = 6;

export default function DimensionDetail() {
  const { id } = useParams();
  const [dimension, setDimension] = useState(null);
  const [allSolutions, setAllSolutions] = useState([]);
  const [technologies, setTechnologies] = useState([]);
  const [search, setSearch] = useState("");
  const [filterTech, setFilterTech] = useState("all");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      db.entities.Dimension.filter({ id }, null, 1),
      db.entities.Solution.filter({ dimension_id: id }, "order", 200),
      db.entities.Technology.list("name", 20),
    ]).then(([dims, sols, techs]) => {
      setDimension(dims[0] || null);
      setAllSolutions(sols);
      setTechnologies(techs);
      setLoading(false);
    });
  }, [id]);

  const filtered = allSolutions.filter((s) => {
    const matchSearch =
      !search ||
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.description?.toLowerCase().includes(search.toLowerCase());
    const matchTech =
      filterTech === "all" ||
      s.technology_names?.some((t) =>
        t.toLowerCase().includes(filterTech.toLowerCase())
      );
    return matchSearch && matchTech;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  if (loading) {
    return (
      <div className="flex justify-center py-32">
        <div className="w-8 h-8 border-4 border-muted border-t-secondary rounded-full animate-spin" />
      </div>
    );
  }

  if (!dimension) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Dimensão não encontrada</h1>
        <Link to="/dimensoes" className="text-secondary mt-4 inline-block">← Voltar para Dimensões</Link>
      </div>
    );
  }

  const IconComp = ICON_MAP[dimension.icon] || Target;
  const stats = DIMENSION_STATS[dimension.code] || [
    { label: "Soluções Mapeadas", value: `${allSolutions.length} Soluções` },
    { label: "Cobertura", value: "Abrangente" },
  ];

  // Unique tech names from solutions in this dimension
  const techsInDimension = [...new Set(allSolutions.flatMap((s) => s.technology_names || []))];

  return (
    <div>
      {/* Hero */}
      <section className="bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
          <Breadcrumbs items={[
            { label: "Dimensões", href: "/dimensoes" },
            { label: dimension.title },
          ]} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-start">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-xl bg-secondary/20 flex items-center justify-center shrink-0">
                  <IconComp className="w-7 h-7 text-secondary" />
                </div>
                <p className="text-secondary text-sm font-semibold tracking-widest uppercase">
                  // {dimension.code}
                </p>
              </div>
              <h1 className="text-3xl md:text-5xl font-bold tracking-tight leading-tight mb-5">
                {dimension.title}
              </h1>
              <div className="space-y-3">
                {dimension.description.split("\n\n").map((p, i) => (
                  <p key={i} className="text-primary-foreground/70 leading-relaxed text-base max-w-2xl">{p}</p>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
              {stats.map((stat, i) => (
                <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-5 backdrop-blur-sm">
                  <p className="text-xs font-semibold tracking-widest uppercase text-secondary mb-2">{stat.label}</p>
                  <p className="text-xl font-bold text-primary-foreground">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-1 h-6 bg-secondary rounded-full" />
            <h2 className="text-2xl font-bold text-foreground">Soluções Mapeadas</h2>
          </div>
          <p className="text-sm text-muted-foreground ml-4">
            Exibindo {paginated.length} de {filtered.length} soluções em {dimension.title}.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-card border border-border rounded-xl p-4 mb-8">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                placeholder="Pesquisar soluções..."
                className="w-full pl-10 pr-4 py-2.5 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-secondary/40 focus:border-secondary transition-all"
              />
            </div>
            <select
              value={filterTech}
              onChange={(e) => { setFilterTech(e.target.value); setPage(1); }}
              className="px-4 py-2.5 text-sm rounded-lg border border-border bg-background outline-none focus:ring-2 focus:ring-secondary/40 focus:border-secondary transition-all"
            >
              <option value="all">Todas as Tecnologias</option>
              {technologies.map((t) => (
                <option key={t.id} value={t.name}>{t.name}</option>
              ))}
            </select>
            <Button variant="outline" size="sm" className="gap-2 self-stretch px-4">
              <Filter className="w-4 h-4" />
              Filtrar
            </Button>
          </div>

          {/* Quick tech badges */}
          {techsInDimension.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {techsInDimension.map((t) => (
                <button
                  key={t}
                  onClick={() => { setFilterTech(filterTech === t ? "all" : t); setPage(1); }}
                  className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                    filterTech === t
                      ? "bg-secondary text-primary border-secondary"
                      : "border-border text-muted-foreground hover:border-secondary/40 hover:text-foreground"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Solutions Grid */}
        {paginated.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground border border-dashed border-border rounded-xl">
            <Search className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">Nenhuma solução encontrada</p>
            <p className="text-sm mt-1">Tente ajustar os filtros ou a busca</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {paginated.map((sol) => (
              <article key={sol.id} className="bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:border-secondary/30 transition-all duration-300 group flex flex-col">
                <span className="inline-flex self-start px-2.5 py-1 rounded-md text-[11px] font-semibold uppercase tracking-wide mb-4 bg-secondary/10 text-secondary">
                  {sol.code}
                </span>
                <h3 className="font-bold text-foreground text-base leading-snug mb-3 group-hover:text-secondary transition-colors">
                  {sol.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">
                  {sol.description}
                </p>
                {sol.technology_names?.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {sol.technology_names.slice(0, 2).map((t) => (
                      <TechBadge key={t} name={t} />
                    ))}
                  </div>
                )}
                <Link
                  to={`/solucao/${sol.id}`}
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-secondary mt-5 hover:gap-3 transition-all"
                >
                  Ver detalhes
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </article>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-12">
            <Button variant="outline" size="icon" disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="w-9 h-9">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
              if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) {
                return (
                  <Button key={p} variant={p === page ? "default" : "outline"} size="icon"
                    className={`w-9 h-9 ${p === page ? "bg-secondary text-primary hover:bg-secondary/90" : ""}`}
                    onClick={() => setPage(p)}>{p}</Button>
                );
              }
              if (Math.abs(p - page) === 2) return <span key={p} className="text-muted-foreground">...</span>;
              return null;
            })}
            <Button variant="outline" size="icon" disabled={page === totalPages} onClick={() => setPage((p) => p + 1)} className="w-9 h-9">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </section>
    </div>
  );
}