const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import { MessageCircle, ArrowRight, BarChart3, Brain, Cog, Globe, Link as LinkIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import DimensionCard from "../components/catalog/DimensionCard";

const HERO_IMAGE = "https://media.db.com/images/public/69ce66d6ee6afb853cd44598/bafdf603a_generated_a08f0a64.png";

const TECH_ICONS = [
  { name: "LLMs", icon: Brain, desc: "Inteligência Artificial" },
  { name: "Data Analytics", icon: BarChart3, desc: "Análise de Dados" },
  { name: "Automação", icon: Cog, desc: "RPA & Automação" },
  { name: "APIs", icon: Globe, desc: "Integração" },
  { name: "Blockchain", icon: LinkIcon, desc: "Segurança" },
];

export default function Home() {
  const [dimensions, setDimensions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Dimension.list("order", 10).then((data) => {
      setDimensions(data);
      setLoading(false);
    });
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-primary overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMAGE} alt="" className="w-full h-full object-cover opacity-30 mix-blend-lighten" />
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary/70" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-secondary text-sm font-semibold tracking-widest uppercase mb-4">
                // Gestão Fiscal (FMM)
              </p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground leading-tight tracking-tight">
                Catálogo de{" "}
                <span className="text-secondary">Soluções</span>{" "}
                para uma Administração Tributária Digital
              </h1>
              <p className="mt-6 text-lg text-primary-foreground/70 leading-relaxed max-w-xl">
                Descubra, explore e reutilize soluções digitais fiscais já testadas e implementadas.
                Um repositório vivo de práticas inovadoras para a transformação digital dos fiscos.
              </p>
              <div className="flex flex-wrap gap-3 mt-8">
                <Link to="/dimensoes">
                  <Button size="lg" className="bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
                    Explorar Catálogo
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to="/chat">
                  <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10 font-semibold gap-2">
                    <MessageCircle className="w-4 h-4" />
                    Navegar via Chat IA
                  </Button>
                </Link>
              </div>
            </div>

            {/* Stats */}
            <div className="hidden lg:grid grid-cols-2 gap-4">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <p className="text-4xl font-bold text-secondary">5</p>
                <p className="text-sm text-primary-foreground/70 mt-1">Dimensões Fazendárias</p>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <p className="text-4xl font-bold text-secondary">40+</p>
                <p className="text-sm text-primary-foreground/70 mt-1">Soluções Catalogadas</p>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <p className="text-4xl font-bold text-secondary">5</p>
                <p className="text-sm text-primary-foreground/70 mt-1">Tecnologias Base</p>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <p className="text-4xl font-bold text-secondary">IA</p>
                <p className="text-sm text-primary-foreground/70 mt-1">Navegação Inteligente</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technologies Strip */}
      <section className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <p className="text-xs font-semibold text-muted-foreground tracking-widest uppercase">Tecnologias</p>
            <div className="flex items-center gap-6 flex-wrap">
              {TECH_ICONS.map((t) => (
                <Link key={t.name} to="/tecnologias" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                  <t.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{t.name}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Dimensions Bento Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="mb-12">
          <p className="text-secondary text-sm font-semibold tracking-widest uppercase mb-3">// Dimensões</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
            Dimensões da Administração Tributária
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl leading-relaxed">
            Navegue pelas grandes áreas da administração tributária. Cada dimensão agrupa soluções que respondem a desafios específicos da gestão fiscal.
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-muted border-t-secondary rounded-full animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {dimensions.slice(0, 2).map((d) => (
              <DimensionCard key={d.id} dimension={d} variant="large" />
            ))}
            <div className="grid gap-4">
              {dimensions.slice(2, 4).map((d) => (
                <DimensionCard key={d.id} dimension={d} />
              ))}
            </div>
            {dimensions.slice(4).map((d) => (
              <DimensionCard key={d.id} dimension={d} />
            ))}
          </div>
        )}
      </section>

      {/* CTA Section */}
      <section className="bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 text-center">
          <p className="text-secondary text-sm font-semibold tracking-widest uppercase mb-4">// Navegação Inteligente</p>
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground tracking-tight mb-4">
            Explore o catálogo via <span className="text-secondary">linguagem natural</span>
          </h2>
          <p className="text-primary-foreground/70 max-w-xl mx-auto mb-8 leading-relaxed">
            Faça perguntas ou descreva suas necessidades — a inteligência artificial encontrará as soluções mais relevantes para você.
          </p>
          <Link to="/chat">
            <Button size="lg" className="bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
              <MessageCircle className="w-5 h-5" />
              Iniciar conversa
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}