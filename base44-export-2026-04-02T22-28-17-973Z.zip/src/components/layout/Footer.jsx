import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                <span className="text-xs font-bold text-primary">BID</span>
              </div>
              <span className="font-semibold">Catálogo de Soluções</span>
            </div>
            <p className="text-sm text-primary-foreground/60 leading-relaxed">
              Banco Interamericano de Desenvolvimento — Divisão Fiscal. Catálogo de Soluções para uma Administração Tributária Digital.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4 text-secondary">Navegação</h4>
            <div className="flex flex-col gap-2">
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">Dimensões</Link>
              <Link to="/tecnologias" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">Tecnologias</Link>
              <Link to="/sobre" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">Sobre o Catálogo</Link>
              <Link to="/chat" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">Chat IA</Link>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4 text-secondary">Dimensões</h4>
            <div className="flex flex-col gap-2">
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">AT 1. Políticas e Gasto Tributário</Link>
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">AT 2. Cadastro e Obrigação Tributária</Link>
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">AT 3. Fiscalização e Inteligência Fiscal</Link>
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">AT 4. Contencioso Fiscal</Link>
              <Link to="/dimensoes" className="text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">AT 5. Serviços ao Contribuinte</Link>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-10 pt-6">
          <p className="text-xs text-primary-foreground/40 text-center">
            © {new Date().getFullYear()} Banco Interamericano de Desenvolvimento. Gestão Fiscal (FMM). Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}