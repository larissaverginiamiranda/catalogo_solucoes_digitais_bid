import { Link, useLocation } from "react-router-dom";
import { useState } from "react";
import { Menu, X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const NAV_ITEMS = [
  { label: "Dimensões", path: "/dimensoes" },
  { label: "Tecnologias", path: "/tecnologias" },
  { label: "Sobre", path: "/sobre" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-primary border-b border-primary/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                <span className="text-xs font-bold text-primary">BID</span>
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-semibold text-primary-foreground leading-tight tracking-tight">Catálogo de Soluções</p>
                <p className="text-[10px] text-primary-foreground/60 leading-tight">Administração Tributária Digital</p>
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  location.pathname.startsWith(item.path)
                    ? "bg-secondary/20 text-secondary"
                    : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/chat">
              <Button size="sm" className="ml-3 bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
                <MessageCircle className="w-4 h-4" />
                Chat IA
              </Button>
            </Link>
          </nav>

          {/* Mobile menu button */}
          <button onClick={() => setOpen(!open)} className="md:hidden text-primary-foreground p-2">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {open && (
        <div className="md:hidden bg-primary border-t border-white/10 pb-4">
          <nav className="flex flex-col px-4 pt-2 gap-1">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setOpen(false)}
                className={`px-4 py-3 text-sm font-medium rounded-md ${
                  location.pathname.startsWith(item.path)
                    ? "bg-secondary/20 text-secondary"
                    : "text-primary-foreground/80"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/chat" onClick={() => setOpen(false)}>
              <Button size="sm" className="mt-2 w-full bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
                <MessageCircle className="w-4 h-4" />
                Chat IA
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}