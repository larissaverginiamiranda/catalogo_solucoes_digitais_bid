export default function TechBadge({ name, variant = "default" }) {
  const baseClasses = "inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-colors";
  const variants = {
    default: "bg-secondary/10 text-secondary border border-secondary/20",
    dark: "bg-white/10 text-white border border-white/20",
    outline: "bg-transparent text-foreground border border-border",
  };

  return (
    <span className={`${baseClasses} ${variants[variant]}`}>
      {name}
    </span>
  );
}