import { Link } from "react-router-dom";
import { ChevronRight, Target, ClipboardList, Search, Scale, Users } from "lucide-react";

const ICON_MAP = {
  Target, ClipboardList, Search, Scale, Users,
};

export default function DimensionCard({ dimension, variant = "default" }) {
  const IconComp = ICON_MAP[dimension.icon] || Target;
  const isLarge = variant === "large";

  return (
    <Link
      to={`/dimensao/${dimension.id}`}
      className={`group relative block rounded-xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
        isLarge ? "bg-primary text-primary-foreground p-8 md:p-10" : "bg-card border border-border p-6 hover:border-secondary/40"
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl mb-4 ${
            isLarge ? "bg-secondary/20" : "bg-primary/5"
          }`}>
            <IconComp className={`w-6 h-6 ${isLarge ? "text-secondary" : "text-primary"}`} />
          </div>
          <p className={`text-xs font-semibold tracking-widest uppercase mb-2 ${
            isLarge ? "text-secondary" : "text-secondary"
          }`}>
            // {dimension.code}
          </p>
          <h3 className={`font-bold tracking-tight leading-tight mb-3 ${
            isLarge ? "text-2xl md:text-3xl" : "text-lg"
          }`}>
            {dimension.title}
          </h3>
          <p className={`text-sm leading-relaxed ${
            isLarge ? "text-primary-foreground/70" : "text-muted-foreground"
          }`}>
            {dimension.short_description}
          </p>
        </div>
      </div>
      <div className={`flex items-center gap-1 mt-4 text-sm font-medium ${
        isLarge ? "text-secondary" : "text-secondary"
      }`}>
        <span>Explorar soluções</span>
        <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}