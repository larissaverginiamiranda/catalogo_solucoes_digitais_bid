import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import TechBadge from "./TechBadge";

export default function SolutionListItem({ solution, variant = "light" }) {
  const isDark = variant === "dark";

  return (
    <Link
      to={`/solucao/${solution.id}`}
      className={`group flex items-center justify-between py-4 px-4 rounded-lg transition-all ${
        isDark
          ? "hover:bg-white/5 border-b border-white/10"
          : "hover:bg-muted border-b border-border"
      }`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-2 mb-1">
          <span className={`text-xs font-semibold ${isDark ? "text-secondary" : "text-secondary"}`}>
            {solution.code}
          </span>
          <h4 className={`font-semibold text-sm truncate ${isDark ? "text-white" : "text-foreground"}`}>
            {solution.title}
          </h4>
        </div>
        {solution.technology_names?.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {solution.technology_names.slice(0, 3).map((t) => (
              <TechBadge key={t} name={t} variant={isDark ? "dark" : "default"} />
            ))}
          </div>
        )}
      </div>
      <ChevronRight className={`w-5 h-5 shrink-0 ml-4 transition-transform group-hover:translate-x-1 ${
        isDark ? "text-white/40 group-hover:text-secondary" : "text-muted-foreground group-hover:text-secondary"
      }`} />
    </Link>
  );
}