const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { Link, useLocation } from "react-router-dom";
import { useState } from "react";
import { Menu, X, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const NAV_ITEMS = [
  { label: "Dimensões", path: "/dimensoes" },
  { label: "Tecnologias", path: "/tecnologias" },
  { label: "Sobre", path: "/sobre" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-primary border-b border-primary/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <img
              src="https://media.db.com/images/public/69ce66d6ee6afb853cd44598/1148ff11b_logo-bid-branca-e1724168191527-1024x493.png"
              alt="BID"
              className="h-7 w-auto"
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  location.pathname.startsWith(item.path)
                    ? "bg-secondary/20 text-secondary"
                    : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/chat">
              <Button size="sm" className="ml-3 bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
                <MessageCircle className="w-4 h-4" />
                Chat IA
              </Button>
            </Link>
          </nav>

          {/* Mobile menu button */}
          <button onClick={() => setOpen(!open)} className="md:hidden text-primary-foreground p-2">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {open && (
        <div className="md:hidden bg-primary border-t border-white/10 pb-4">
          <nav className="flex flex-col px-4 pt-2 gap-1">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setOpen(false)}
                className={`px-4 py-3 text-sm font-medium rounded-md ${
                  location.pathname.startsWith(item.path)
                    ? "bg-secondary/20 text-secondary"
                    : "text-primary-foreground/80"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/chat" onClick={() => setOpen(false)}>
              <Button size="sm" className="mt-2 w-full bg-secondary text-primary hover:bg-secondary/90 font-semibold gap-2">
                <MessageCircle className="w-4 h-4" />
                Chat IA
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}