const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";

import { Send, ArrowRight, Layers, Cpu, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

const QUICK_PROMPTS = [
  "Soluções de fiscalização com IA",
  "Cadastro tributário automatizado",
  "Cobrança e dívida ativa digital",
  "Atendimento ao contribuinte",
];

const SYSTEM_PROMPT = `Você é um assistente especializado no Catálogo de Soluções Digitais da Administração Tributária do BID (Banco Interamericano de Desenvolvimento).
Você conhece profundamente as 5 dimensões: AT1 (Planejamento Fiscal), AT2 (Gestão Cadastral), AT3 (Controle e Fiscalização), AT4 (Cobrança e Gestão da Dívida), AT5 (Atendimento e Serviços ao Contribuinte).
Tecnologias abordadas: IA/LLMs, Blockchain, RPA, APIs, Data Analytics, Machine Learning.
Responda em português, de forma objetiva e útil, indicando dimensões e soluções relevantes quando apropriado.`;

export default function Home() {
  const [solutions, setSolutions] = useState([]);
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    db.entities.Solution.list("order", 4).then(setSolutions);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (text) => {
    if (!text.trim()) return;
    const userMsg = { role: "user", content: text };
    const history = [...messages, userMsg];
    setMessages(history);
    setQuery("");
    setLoading(true);

    const prompt = `${SYSTEM_PROMPT}\n\nHistórico:\n${history.map((m) => `${m.role === "user" ? "Usuário" : "Assistente"}: ${m.content}`).join("\n")}\n\nResponda ao último pedido do usuário.`;

    const response = await db.integrations.Core.InvokeLLM({ prompt });
    setMessages([...history, { role: "assistant", content: response }]);
    setLoading(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(query);
  };

  return (
    <div className="min-h-screen bg-primary flex flex-col">
      {/* Hero + Chat */}
      <section className="flex-1 flex flex-col items-center justify-center px-4 py-16 md:py-24">
        <div className="w-full max-w-2xl text-center">
          {/* Badge */}
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/20 text-secondary text-xs font-semibold uppercase tracking-widest mb-6">
            BID · Divisão Fiscal
          </span>

          {/* Title */}
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground tracking-tight leading-tight mb-10">
            Catálogo de Soluções Digitais da{" "}
            <span className="text-secondary">Administração Tributária</span>
          </h1>

          {/* Chat Messages */}
          {messages.length > 0 && (
            <div className="mb-6 space-y-3 text-left max-h-72 overflow-y-auto pr-1">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
                      m.role === "user"
                        ? "bg-secondary text-primary"
                        : "bg-white/10 text-primary-foreground border border-white/10"
                    }`}
                  >
                    {m.role === "assistant" ? (
                      <ReactMarkdown className="prose prose-sm prose-invert max-w-none">
                        {m.content}
                      </ReactMarkdown>
                    ) : (
                      m.content
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white/10 border border-white/10 rounded-2xl px-4 py-2.5">
                    <Loader2 className="w-4 h-4 text-secondary animate-spin" />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          )}

          {/* Chat Input */}
          <form onSubmit={handleSubmit} className="relative w-full">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Como posso te auxiliar hoje? Ex: soluções de fiscalização com IA…"
              className="w-full rounded-2xl border border-white/20 bg-white/10 shadow-sm px-6 py-4 pr-14 text-sm text-primary-foreground placeholder:text-white/50 outline-none focus:ring-2 focus:ring-secondary/60 focus:border-secondary transition-all backdrop-blur-sm"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-xl bg-secondary text-primary flex items-center justify-center hover:bg-secondary/90 transition-colors disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Quick prompts */}
          {messages.length === 0 && (
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {QUICK_PROMPTS.map((p) => (
                <button
                  key={p}
                  onClick={() => sendMessage(p)}
                  className="px-3 py-1.5 rounded-full border border-white/20 text-xs text-white/70 hover:border-secondary/60 hover:text-secondary transition-colors bg-white/5"
                >
                  {p}
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Solutions */}
      {solutions.length > 0 && (
        <section className="max-w-4xl mx-auto w-full px-4 pb-16">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-sm font-semibold text-white/50 uppercase tracking-widest">Soluções em Destaque</h2>
            <Link to="/dimensoes" className="flex items-center gap-1 text-xs font-semibold text-secondary hover:underline">
              Ver todas <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {solutions.map((s) => (
              <Link key={s.id} to={`/solucao/${s.id}`} className="group">
                <article className="bg-white/5 border border-white/10 rounded-xl p-5 hover:shadow-md hover:border-secondary/40 transition-all duration-300 h-full flex flex-col">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-secondary mb-3">{s.code}</span>
                  <h3 className="text-sm font-semibold text-primary-foreground leading-snug flex-1 group-hover:text-secondary transition-colors">
                    {s.title}
                  </h3>
                  <div className="flex items-center gap-1 text-xs font-medium text-secondary mt-4">
                    Ver detalhes <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </article>
              </Link>
            ))}
          </div>

          {/* Explore links */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <Link to="/dimensoes" className="group flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-5 hover:shadow-md hover:border-secondary/40 transition-all">
              <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                <Layers className="w-4 h-4 text-secondary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-primary-foreground">Explorar por Dimensão</p>
                <p className="text-xs text-white/50">5 dimensões fazendárias</p>
              </div>
              <ArrowRight className="w-4 h-4 text-secondary ml-auto group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/tecnologias" className="group flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-5 hover:shadow-md hover:border-secondary/40 transition-all">
              <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                <Cpu className="w-4 h-4 text-secondary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-primary-foreground">Explorar por Tecnologia</p>
                <p className="text-xs text-white/50">IA, Blockchain, APIs e mais</p>
              </div>
              <ArrowRight className="w-4 h-4 text-secondary ml-auto group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </section>
      )}
    </div>
  );
}